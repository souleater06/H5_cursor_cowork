; cursor_rpa.ahk
; Two modes:
; 1) Calibrate mode: AutoHotkeyU64.exe cursor_rpa.ahk --calibrate
;    - Press F8 to record: input box
;    - Save to cursor_rpa.ini
; 2) Run mode: AutoHotkeyU64.exe cursor_rpa.ahk "<skill_file_path>"
;    - Load offsets from cursor_rpa.ini and run automation (text only)

; AutoHotkey v1-compatible CLI argument read
arg1 = %1%
configPath := A_ScriptDir . "\cursor_rpa.ini"

if (arg1 = "--calibrate")
{
    Gosub, StartCalibrate
    return
}
else
{
    skillPath := arg1
    if (skillPath = "")
    {
        MsgBox, 48, Notice, Missing skill file path.`nUse --calibrate or pass a file path.
        ExitApp
    }
    Gosub, RunAutomation
    return
}

StartCalibrate:
step := 1
MsgBox, 64, Calibrate Mode, Calibration started.`nPlease bring Cursor window to front.`n`nPress F8 once to capture:`n1) Input box
Hotkey, F8, CapturePoint, On
Hotkey, Esc, ExitScript, On
return

CapturePoint:
if !WinActive("ahk_exe Cursor.exe")
{
    MsgBox, 48, Notice, Activate the Cursor window first, then press F8.
    return
}
MouseGetPos, mx, my
WinGetPos, wx, wy, ww, wh, A
ox := mx - wx
oy := my - wy

if (step = 1)
{
    IniWrite, %ox%, %configPath%, offsets, inputX
    IniWrite, %oy%, %configPath%, offsets, inputY
    step := 2
    MsgBox, 64, Done, Offsets saved to`n%configPath%
    ExitApp
}
return

RunAutomation:
IfWinExist, ahk_exe Cursor.exe
{
    WinActivate
    WinWaitActive
}
else
{
    MsgBox, 48, Error, Cursor window not found. Script will exit.
    ExitApp
}

; Default offsets (used if not calibrated)
inputOffsetX := 300
inputOffsetY := 800

; Load calibrated offsets (override defaults if present)
IniRead, tmp, %configPath%, offsets, inputX, %inputOffsetX%
inputOffsetX := tmp
IniRead, tmp, %configPath%, offsets, inputY, %inputOffsetY%
inputOffsetY := tmp

WinGetPos, winX, winY, winW, winH, A

inputX := winX + inputOffsetX
inputY := winY + inputOffsetY
Click, %inputX%, %inputY%
Sleep, 120
Send, ^v
Sleep, 250

Send, {Enter}
Sleep, 900

ExitApp
return

RemoveToolTip:
ToolTip
return

ExitScript:
ExitApp
return

