#Requires AutoHotkey v2.0

arg1 := A_Args.Length >= 1 ? A_Args[1] : ""
configPath := A_ScriptDir "\cursor_rpa.ini"

if (arg1 = "--calibrate") {
    StartCalibrate(configPath)
    ExitApp
}

if (arg1 = "") {
    MsgBox "Missing skill file path.`nUse --calibrate or pass a file path.", "Notice", "Icon!"
    ExitApp
}

RunAutomation(configPath)
ExitApp

StartCalibrate(configPath) {
    MsgBox "Calibration started.`nPlease activate Cursor window, then press F8 to capture input box.", "Calibrate Mode", "Iconi"
    Hotkey "F8", (*) => CapturePoint(configPath)
    Hotkey "Esc", (*) => ExitApp()
    KeyWait "Esc", "D"
}

CapturePoint(configPath) {
    if !WinActive("ahk_exe Cursor.exe") {
        MsgBox "Activate Cursor window first, then press F8.", "Notice", "Icon!"
        return
    }
    MouseGetPos &mx, &my
    WinGetPos &wx, &wy, &ww, &wh, "A"
    ox := mx - wx
    oy := my - wy
    IniWrite ox, configPath, "offsets", "inputX"
    IniWrite oy, configPath, "offsets", "inputY"
    MsgBox "Offsets saved to`n" configPath, "Done", "Iconi"
    ExitApp
}

RunAutomation(configPath) {
    hwnd := WinExist("ahk_exe Cursor.exe")
    if !hwnd {
        MsgBox "Cursor window not found. Script exits.", "Error", "Iconx"
        ExitApp
    }
    WinActivate "ahk_id " hwnd
    WinWaitActive "ahk_id " hwnd, , 2

    inputOffsetX := IniRead(configPath, "offsets", "inputX", 300)
    inputOffsetY := IniRead(configPath, "offsets", "inputY", 800)

    WinGetPos &winX, &winY, &winW, &winH, "ahk_id " hwnd
    inputX := winX + Integer(inputOffsetX)
    inputY := winY + Integer(inputOffsetY)

    Click inputX, inputY
    Sleep 120
    Send "^v"
    Sleep 250
    Send "{Enter}"
    Sleep 400
}
