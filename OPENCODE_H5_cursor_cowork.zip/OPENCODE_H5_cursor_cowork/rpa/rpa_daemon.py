from __future__ import annotations

import os
import subprocess
import time
import shutil
from pathlib import Path
from typing import Any, Dict, Optional

import pyperclip
import requests


BACKEND_BASE_URL = "http://127.0.0.1:8000"
POLL_INTERVAL_SECONDS = 2
IDLE_LOG_EVERY_N = 15  # 空闲时每 N 次轮询打印一次心跳日志
HEARTBEAT_EVERY_N = 5


def resolve_autohotkey_exe() -> Optional[str]:
    """
    解析 AutoHotkey 可执行文件路径。

    优先级：
    1) 环境变量 AHK_EXE 指定的路径
    2) PATH 中的 autohotkey.exe
    3) 常见安装路径（AutoHotkey v2 / v1）
    """
    env = os.environ.get("AHK_EXE")
    if env and Path(env).exists():
        return env

    # 从 PATH 中解析（更可靠）
    for name in ["AutoHotkeyU64.exe", "autohotkey.exe", "AutoHotkey.exe"]:
        found = shutil.which(name)
        if found:
            return found

    # 常见安装位置（优先 v1，再 v2，避免 v1 脚本被 v2 解释器直接拒绝）
    candidates = [
        r"C:\Program Files\AutoHotkey\AutoHotkeyU64.exe",
        r"C:\Program Files\AutoHotkey\AutoHotkeyA32.exe",
        r"C:\Program Files\AutoHotkey\AutoHotkey.exe",
        r"C:\Program Files (x86)\AutoHotkey\AutoHotkey.exe",
        r"C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe",
        r"C:\Program Files\AutoHotkey\v2\AutoHotkey.exe",
    ]
    for p in candidates:
        if Path(p).exists():
            return p

    return None


def is_ahk_v2(ahk_exe: str) -> bool:
    exe = ahk_exe.lower()
    return "\\v2\\" in exe or exe.endswith("autohotkey64.exe")


def fetch_next_task() -> Optional[Dict[str, Any]]:
    """
    从后端轮询一条待处理的 Cursor 任务。
    """
    url = f"{BACKEND_BASE_URL}/api/next_task_for_cursor"
    try:
        resp = requests.get(url, timeout=5)
    except Exception as e:
        print(f"轮询失败: {e}")
        return None

    if resp.status_code != 200:
        print(f"轮询返回非 200: {resp.status_code}")
        return None

    data = resp.json()
    if not data.get("has_task"):
        return None
    return data


def report_task(task_id: str, status: str, message: str) -> None:
    url = f"{BACKEND_BASE_URL}/api/rpa/report"
    payload = {"task_id": task_id, "status": status, "message": message}
    try:
        requests.post(url, json=payload, timeout=5)
    except Exception as e:
        print(f"回传任务状态失败: {e}")


def send_heartbeat() -> None:
    url = f"{BACKEND_BASE_URL}/api/rpa/heartbeat"
    try:
        requests.post(url, timeout=5)
    except Exception as e:
        print(f"发送 RPA 心跳失败: {e}")


def handle_task(task: Dict[str, Any]) -> None:
    """
    处理一条任务：
    - 把 clipboard_text 写入系统剪贴板；
    - 调用 AutoHotkey 脚本，传入 skill 文件路径。
    """
    clipboard_text = task.get("clipboard_text") or ""
    skill_file_path = task.get("skill_file_path") or ""
    task_id = task.get("task_id") or ""

    print(f"写入剪贴板，文本长度={len(clipboard_text)}")
    print(f"skill 文件: {skill_file_path}")

    # 写入剪贴板
    pyperclip.copy(clipboard_text)

    script_dir = Path(__file__).resolve().parent
    ahk_exe = resolve_autohotkey_exe()
    if not ahk_exe:
        print(
            "未找到 AutoHotkey 可执行文件。\n"
            "- 方案1：安装 AutoHotkey，并把 autohotkey.exe 加入 PATH\n"
            "- 方案2：设置环境变量 AHK_EXE 为 AutoHotkey.exe 的绝对路径"
        )
        if task_id:
            report_task(task_id, "failed", "AutoHotkey executable not found")
        return

    ahk_script_name = "cursor_rpa_v2.ahk" if is_ahk_v2(ahk_exe) else "cursor_rpa.ahk"
    ahk_script = str(script_dir / ahk_script_name)
    if not Path(ahk_script).exists():
        if task_id:
            report_task(task_id, "failed", f"AHK script not found: {ahk_script_name}")
        return

    print(f"使用 AHK: {ahk_exe}")
    print(f"执行脚本: {ahk_script_name}")

    try:
        proc = subprocess.run(
            [ahk_exe, ahk_script, skill_file_path],
            cwd=str(script_dir),
            capture_output=True,
            text=True,
            timeout=20,
        )
        if task_id:
            if proc.returncode == 0:
                report_task(task_id, "done", "AHK automation completed")
            else:
                stderr = (proc.stderr or "").strip()
                stdout = (proc.stdout or "").strip()
                msg = stderr or stdout or f"AHK failed with code {proc.returncode}"
                report_task(task_id, "failed", msg[:500])
    except FileNotFoundError:
        print(
            f"启动 AutoHotkey 失败（找不到可执行文件）：{ahk_exe}\n"
            "请确认已安装 AutoHotkey，并把其路径加入 PATH，或设置 AHK_EXE。"
        )
        if task_id:
            report_task(task_id, "failed", "Failed to launch AutoHotkey process")
    except subprocess.TimeoutExpired:
        print("AHK 执行超时。")
        if task_id:
            report_task(task_id, "failed", "AHK execution timeout")


def main_loop() -> None:
    print("RPA 守护进程已启动，开始轮询后端任务...")
    idle = 0
    tick = 0
    try:
        while True:
            tick += 1
            if tick % HEARTBEAT_EVERY_N == 0:
                send_heartbeat()
            task = fetch_next_task()
            if task:
                idle = 0
                print(f"获取到任务: {task.get('task_id')}")
                handle_task(task)
            else:
                idle += 1
                if idle % IDLE_LOG_EVERY_N == 0:
                    print("暂无新任务，继续轮询...")
            time.sleep(POLL_INTERVAL_SECONDS)
    except KeyboardInterrupt:
        print("收到 Ctrl+C，RPA 守护进程退出。")


if __name__ == "__main__":
    main_loop()

