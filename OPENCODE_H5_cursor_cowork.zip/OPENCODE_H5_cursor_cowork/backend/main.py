from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .models import (
    DistilledContext,
    H5CommandResponse,
    H5Request,
    NextTaskResponse,
    PendingCursorTask,
    RPAReportRequest,
    SkillSnapshot,
)


BASE_DIR = Path(__file__).resolve().parent.parent
H5_DIR = BASE_DIR / "h5"
H5_DIR.mkdir(parents=True, exist_ok=True)
SKILLS_DIR = BASE_DIR / "skills"
SKILLS_DIR.mkdir(parents=True, exist_ok=True)

PENDING_TASKS: List[PendingCursorTask] = []
TASK_EVENTS: list[dict] = []
SNAPSHOTS: list[dict] = []
RPA_LAST_HEARTBEAT_AT: datetime | None = None


def _now() -> datetime:
    return datetime.now(timezone.utc)


app = FastAPI(title="H5 Cursor Cowork Backend", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/h5", StaticFiles(directory=str(H5_DIR), html=True), name="h5")


@app.get("/")
def root():
    return {"status": "ok", "message": "H5_cursor_cowork backend running"}


@app.get("/api/system/status")
def system_status():
    now = _now()
    rpa_online = False
    if RPA_LAST_HEARTBEAT_AT is not None:
        rpa_online = (now - RPA_LAST_HEARTBEAT_AT).total_seconds() <= 12
    return {
        "backend_online": True,
        "rpa_online": rpa_online,
        "rpa_last_heartbeat_at": RPA_LAST_HEARTBEAT_AT.isoformat() if RPA_LAST_HEARTBEAT_AT else None,
    }


@app.post("/api/h5/command", response_model=H5CommandResponse)
def handle_h5_command(req: H5Request):
    """
    H5 侧调用：
    - 接收会话 + 源码 + 本次指令。
    - 生成蒸馏上下文、skill 文件、待发送给 Cursor 的任务。
    """
    effective_messages = build_effective_messages(req.messages, req.user_instruction)
    distilled = distill_conversation(req, effective_messages)
    source_files = req.source_files or {}
    skill_snapshot = create_snapshot(distilled, effective_messages, source_files)
    clipboard_text = render_cursor_prompt(distilled, req.user_instruction)
    task = create_pending_cursor_task(
        clipboard_text,
        skill_snapshot.file_path,
        req.conversation_id,
        skill_snapshot.id,
    )
    append_task_event(
        conversation_id=req.conversation_id,
        task_id=task.id,
        event_type="queued",
        message=f"Queued task {task.id}",
        status=task.status,
    )

    return H5CommandResponse(
        skill_id=skill_snapshot.id,
        task_id=task.id,
        clipboard_preview=clipboard_text[:200] + ("..." if len(clipboard_text) > 200 else ""),
        snapshot=skill_snapshot,
    )


@app.get("/api/h5/snapshots/latest")
def get_latest_snapshot(conversation_id: str | None = None):
    items = SNAPSHOTS
    if conversation_id:
        items = [x for x in SNAPSHOTS if x.get("distilled", {}).get("conversation_id") == conversation_id]
    if not items:
        return {"has_snapshot": False}
    return {"has_snapshot": True, "snapshot": items[-1]}


@app.get("/api/h5/snapshots")
def list_snapshots(limit: int = 20, conversation_id: str | None = None):
    items_src = SNAPSHOTS[-limit:]
    items = []
    for data in reversed(items_src):
        cid = data.get("distilled", {}).get("conversation_id")
        if conversation_id and cid != conversation_id:
            continue
        items.append(
            {
                "id": data.get("id"),
                "created_at": data.get("created_at"),
                "conversation_id": cid,
                "summary": data.get("distilled", {}).get("summary", ""),
                "related_files_count": len(data.get("distilled", {}).get("related_files", [])),
                "task_status": find_task_status_by_skill_id(data.get("id", "")),
            }
        )
    return {"items": items}


@app.get("/api/h5/snapshots/{skill_id}")
def get_snapshot_detail(skill_id: str):
    data = next((x for x in SNAPSHOTS if x.get("id") == skill_id), None)
    if data is None:
        return {"found": False}
    return {"found": True, "snapshot": data, "task_status": find_task_status_by_skill_id(data.get("id", ""))}


@app.get("/api/h5/events")
def list_events(limit: int = 50, conversation_id: str | None = None):
    items = TASK_EVENTS
    if conversation_id:
        items = [e for e in items if e.get("conversation_id") == conversation_id]
    return {"items": items[-limit:]}


@app.get("/api/h5/review/current-folder")
def review_current_folder():
    """
    轻量代码 review：扫描当前项目目录，返回统计和明显风险项。
    """
    target = BASE_DIR
    file_count = 0
    line_count = 0
    py_count = 0
    js_count = 0
    html_count = 0
    findings: list[str] = []

    for p in target.rglob("*"):
        if not p.is_file():
            continue
        # 跳过常见无关目录
        low = str(p).lower()
        if "\\.git\\" in low or "\\__pycache__\\" in low:
            continue

        file_count += 1
        ext = p.suffix.lower()
        if ext == ".py":
            py_count += 1
        elif ext in [".js", ".ts"]:
            js_count += 1
        elif ext == ".html":
            html_count += 1

        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        line_count += text.count("\n") + 1

        # 轻量风险规则
        if "allow_origins=[\"*\"]" in text:
            findings.append(f"CORS wildcard in {p.name}")
        if "TODO" in text or "FIXME" in text:
            findings.append(f"TODO/FIXME found in {p.name}")
        if "print(" in text and ext == ".py":
            findings.append(f"Debug print() found in {p.name}")

    # 去重并限制长度
    unique_findings = []
    seen = set()
    for f in findings:
        if f in seen:
            continue
        seen.add(f)
        unique_findings.append(f)
        if len(unique_findings) >= 12:
            break

    score = 100
    score -= min(len(unique_findings) * 5, 40)
    if score < 60:
        level = "high-risk"
    elif score < 80:
        level = "medium-risk"
    else:
        level = "low-risk"

    return {
        "target_folder": str(target),
        "summary": {
            "files": file_count,
            "lines": line_count,
            "python_files": py_count,
            "js_ts_files": js_count,
            "html_files": html_count,
        },
        "review": {
            "score": score,
            "risk_level": level,
            "findings": unique_findings,
        },
    }


@app.post("/api/rpa/report")
def report_rpa(req: RPAReportRequest):
    task = next((t for t in PENDING_TASKS if t.id == req.task_id), None)
    if not task:
        return {"ok": False, "error": "task_not_found"}
    task.status = req.status
    append_task_event(
        conversation_id=task.conversation_id or "",
        task_id=task.id,
        event_type="rpa_report",
        message=req.message or req.status,
        status=req.status,
    )
    return {"ok": True}


@app.post("/api/rpa/heartbeat")
def rpa_heartbeat():
    global RPA_LAST_HEARTBEAT_AT
    RPA_LAST_HEARTBEAT_AT = _now()
    return {"ok": True, "at": RPA_LAST_HEARTBEAT_AT.isoformat()}


@app.get("/api/next_task_for_cursor", response_model=NextTaskResponse)
def next_task_for_cursor():
    """
    RPA 守护进程轮询这个接口，获取下一条需要发给 Cursor 的任务。
    """
    for task in PENDING_TASKS:
        if task.status == "pending":
            task.status = "dispatched"
            append_task_event(
                conversation_id=task.conversation_id or "",
                task_id=task.id,
                event_type="dispatched",
                message="Task dispatched to RPA",
                status=task.status,
            )
            return NextTaskResponse(
                has_task=True,
                task_id=task.id,
                clipboard_text=task.clipboard_text,
                skill_file_path=task.skill_file_path,
                conversation_id=task.conversation_id,
                skill_id=task.skill_id,
            )
    return NextTaskResponse(has_task=False)


def distill_conversation(req: H5Request, messages: list[dict]) -> DistilledContext:
    """
    极简版“蒸馏”：真实使用中可以接大模型，这里先做占位实现。
    """
    # 手机端场景的轻量蒸馏：取最近几条消息拼接，避免长上下文造成输入负担。
    last_messages = messages[-5:]
    summary_chunks = []
    for m in last_messages:
        role = m.get("role", "user")
        content = m.get("content", "")
        summary_chunks.append(f"[{role}] {content}")
    summary = "\n".join(summary_chunks)

    # 关键指令拆解：按换行拆成短句，模拟移动端“意图条目”体验。
    key_instructions = []
    for line in req.user_instruction.splitlines():
        text = line.strip(" -\t")
        if text:
            key_instructions.append(text)
    if not key_instructions and req.user_instruction.strip():
        key_instructions = [req.user_instruction.strip()]

    # 简单猜测相关文件：如果 H5 提供了 source_files，就把 key 全列出来。
    related_files = list((req.source_files or {}).keys())

    # 代码片段：此处直接全量放入，真实使用中可以按需截断。
    code_snippets = {}
    if req.source_files:
        for path, content in req.source_files.items():
            loc = f"{path}:full"
            code_snippets[loc] = content

    return DistilledContext(
        conversation_id=req.conversation_id,
        summary=summary,
        key_instructions=key_instructions,
        related_files=related_files,
        code_snippets=code_snippets,
    )


def create_snapshot(
    distilled: DistilledContext,
    messages: list[dict],
    source_files: dict[str, str],
) -> SkillSnapshot:
    skill_id = str(uuid.uuid4())
    file_path = str(SKILLS_DIR / f"{skill_id}.json")
    snapshot = SkillSnapshot(
        id=skill_id,
        created_at=_now(),
        distilled=distilled,
        raw_messages=messages[-20:],
        source_files=source_files,
        apply_hints=[
            "1. 优先按 key_instructions 顺序执行，避免一次修改过多模块。",
            "2. 如需改动文件，先说明影响面，再输出最小可行补丁。",
            "3. 保持与现有代码风格一致，完成后给出验证步骤。",
        ],
        file_path=file_path,
    )
    raw = snapshot.model_dump(mode="json")
    SNAPSHOTS.append(raw)
    if len(SNAPSHOTS) > 500:
        del SNAPSHOTS[:200]
    Path(file_path).write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    return snapshot


def create_pending_cursor_task(
    clipboard_text: str,
    skill_path: str,
    conversation_id: str,
    skill_id: str,
) -> PendingCursorTask:
    task = PendingCursorTask(
        id=str(uuid.uuid4()),
        created_at=_now(),
        clipboard_text=clipboard_text,
        skill_file_path=skill_path,
        conversation_id=conversation_id,
        skill_id=skill_id,
        status="pending",
    )
    PENDING_TASKS.append(task)
    return task


def find_task_status_by_skill_id(skill_id: str) -> str:
    for task in PENDING_TASKS:
        if task.skill_id == skill_id:
            return task.status
    return "unknown"


def render_cursor_prompt(distilled: DistilledContext, user_instruction: str) -> str:
    """
    生成要粘贴到 Cursor 对话里的文本（移动端友好的结构化提示）。
    """
    blocks = [
        "你是 Cursor 协作助手，请按以下上下文执行：",
        f"[conversation_id]\n{distilled.conversation_id}",
        f"[用户目标]\n{user_instruction.strip()}",
    ]
    if distilled.summary.strip():
        blocks.append(f"[最近对话摘要]\n{distilled.summary.strip()}")
    if distilled.key_instructions:
        blocks.append("[关键执行点]\n" + "\n".join(f"- {x}" for x in distilled.key_instructions[:8]))
    if distilled.related_files:
        blocks.append("[相关文件]\n" + "\n".join(f"- {x}" for x in distilled.related_files[:20]))
    return "\n\n".join(blocks).strip()


def build_effective_messages(messages: list[dict], user_instruction: str) -> list[dict]:
    merged = list(messages or [])
    text = (user_instruction or "").strip()
    if not text:
        return merged
    if not merged or merged[-1].get("content") != text:
        merged.append({"role": "user", "content": text})
    return merged


def append_task_event(conversation_id: str, task_id: str, event_type: str, message: str, status: str) -> None:
    TASK_EVENTS.append(
        {
            "at": _now().isoformat(),
            "conversation_id": conversation_id,
            "task_id": task_id,
            "type": event_type,
            "message": message,
            "status": status,
        }
    )
    # 防止无限增长
    if len(TASK_EVENTS) > 2000:
        del TASK_EVENTS[:1000]

