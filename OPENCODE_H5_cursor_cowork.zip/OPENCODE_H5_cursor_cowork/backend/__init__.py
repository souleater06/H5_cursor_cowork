"""
H5_cursor_cowork backend package.

包含 FastAPI 应用及相关数据模型。
"""

