from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class H5Request(BaseModel):
    """H5 页面发给后端的一次指令请求。"""

    conversation_id: str
    messages: List[Dict] = Field(
        default_factory=list,
        description="最近若干条对话记录，例如 [{'role': 'user', 'content': '...'}]",
    )
    source_files: Optional[Dict[str, str]] = Field(
        default=None,
        description="可选：相关源码内容，键为路径，值为文件内容。",
    )
    user_instruction: str = Field(
        description="本次在 H5 输入框中输入的指令。",
    )


class DistilledContext(BaseModel):
    """蒸馏后的上下文简化结构。"""

    conversation_id: str
    summary: str
    key_instructions: List[str] = Field(default_factory=list)
    related_files: List[str] = Field(default_factory=list)
    code_snippets: Dict[str, str] = Field(
        default_factory=dict,
        description="键为 'path:line_range'，值为代码片段。",
    )


class SkillSnapshot(BaseModel):
    """本地 skill 快照文件的元信息。"""

    id: str
    created_at: datetime
    distilled: DistilledContext
    raw_messages: List[Dict] = Field(
        default_factory=list,
        description="可选：保留最近若干条原始消息。",
    )
    source_files: Dict[str, str] = Field(
        default_factory=dict,
        description="本次请求中附带的源码内容（完整保留）。",
    )
    apply_hints: List[str] = Field(
        default_factory=list,
        description="给下游（例如 Cursor 对话）的一些使用提示。",
    )
    file_path: str = Field(description="本地 skill JSON 文件的完整路径。")


class PendingCursorTask(BaseModel):
    """等待本地 RPA / Cursor 处理的一条任务。"""

    id: str
    created_at: datetime
    clipboard_text: str
    skill_file_path: str
    conversation_id: Optional[str] = None
    skill_id: Optional[str] = None
    status: str = Field(
        default="pending",
        description="任务状态：pending / dispatched / done 等。",
    )


class NextTaskResponse(BaseModel):
    """RPA 守护进程轮询获取的任务响应。"""

    has_task: bool
    task_id: Optional[str] = None
    clipboard_text: Optional[str] = None
    skill_file_path: Optional[str] = None
    conversation_id: Optional[str] = None
    skill_id: Optional[str] = None


class H5CommandResponse(BaseModel):
    """H5 提交指令后的响应。"""

    skill_id: str
    task_id: str
    clipboard_preview: str
    snapshot: SkillSnapshot


class RPAReportRequest(BaseModel):
    """RPA 回传任务执行状态。"""

    task_id: str
    status: str
    message: str = ""

