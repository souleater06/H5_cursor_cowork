H5_CURSOR_COWORK
================

开箱即用的本地协作桥接工具：`H5 页面 -> 蒸馏 -> RPA -> Cursor`。

## 一键启动（Windows）

在项目根目录执行任一命令：

```powershell
.\start_all.ps1
```

或：

```bat
start_all.bat
```

如果 AutoHotkey 不在 PATH，指定可执行文件：

```powershell
.\start_all.ps1 -AhkExe "D:\Admin\autokey\AutoHotkeyU64.exe"
```

启动后会自动：

1. 安装依赖（可用 `-SkipInstall` 跳过）
2. 启动后端 `uvicorn`
3. 启动 `rpa_daemon.py`
4. 打开 H5 页面 `http://127.0.0.1:8000/h5`

## 当前功能

- H5 聊天区实时显示：
  - 用户输入
  - 任务排队/下发/RPA回传状态
- 边栏显示当前文件夹代码 Review（可刷新）
- RPA 在线状态灯（心跳检测）
- 发送前预览与一键复制
- 蒸馏快照走内存存储（新请求默认不落盘）

## 目录说明

- `backend/main.py`：后端主入口（接口、蒸馏、任务与事件流）
- `backend/models.py`：请求/响应数据模型
- `h5/index.html`：移动端适配 H5 页面
- `rpa/rpa_daemon.py`：RPA 守护进程
- `rpa/cursor_rpa.ahk`：Cursor 自动输入脚本
- `start_all.ps1`：一键启动脚本（推荐）
- `start_all.bat`：双击启动入口
- `OPENCODE_MOBILE_GITHUB_拆解.md`：OpenCode 手机端逻辑拆解与本项目映射

## 常见问题

- `RPA offline`：确认 `rpa_daemon.py` 窗口在运行
- `AutoHotkey not found`：用 `-AhkExe` 指定路径
- 输入框点错：先执行 AHK 校准模式重新记录坐标
- AHK v2 用户：
  - 项目已内置 `rpa/cursor_rpa_v2.ahk`，守护进程会自动识别并使用。
  - 如需手动指定解释器，可执行：
    - `.\start_all.ps1 -AhkExe "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"`

## RPA 自检建议

1. 后端健康检查：
   - 打开 `http://127.0.0.1:8000/api/system/status`
2. RPA 手动启动：
   - 进入 `rpa` 目录运行 `python rpa_daemon.py`
3. AHK 校准：
   - `AutoHotkeyU64.exe .\cursor_rpa.ahk --calibrate`
   - 或 `AutoHotkey64.exe .\cursor_rpa_v2.ahk --calibrate`

