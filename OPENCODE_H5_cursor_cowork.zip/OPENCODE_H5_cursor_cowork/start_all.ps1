param(
    [string]$PythonExe = "python",
    [string]$BackendHost = "127.0.0.1",
    [int]$BackendPort = 8000,
    [string]$AhkExe = "",
    [switch]$SkipInstall
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

Write-Host "== H5_CURSOR_COWORK one-click startup ==" -ForegroundColor Cyan
Write-Host "Root: $root"

if (-not $SkipInstall) {
    Write-Host "`n[1/4] Installing dependencies..." -ForegroundColor Yellow
    & $PythonExe -m pip install --user -r "$root\requirements.txt"
}
else {
    Write-Host "`n[1/4] Skip install requested." -ForegroundColor Yellow
}

if ($AhkExe -ne "") {
    $env:AHK_EXE = $AhkExe
    Write-Host "`nAHK_EXE set to: $AhkExe" -ForegroundColor Green
}

Write-Host "`n[2/4] Starting backend server..." -ForegroundColor Yellow
Start-Process -FilePath $PythonExe `
    -ArgumentList @("-m", "uvicorn", "backend.main:app", "--reload", "--host", $BackendHost, "--port", "$BackendPort") `
    -WorkingDirectory $root | Out-Null

Start-Sleep -Seconds 2

Write-Host "[3/4] Starting RPA daemon..." -ForegroundColor Yellow
Start-Process -FilePath $PythonExe `
    -ArgumentList @("rpa_daemon.py") `
    -WorkingDirectory "$root\rpa" | Out-Null

Write-Host "[4/4] Opening H5 page..." -ForegroundColor Yellow
$url = "http://$BackendHost`:$BackendPort/h5"
Start-Process $url | Out-Null

Write-Host "`nDone." -ForegroundColor Green
Write-Host "Backend API: http://$BackendHost`:$BackendPort"
Write-Host "H5 Page:     $url"
Write-Host "`nTips:"
Write-Host "- Keep both PowerShell windows open."
Write-Host "- If AutoHotkey path is custom, run:"
Write-Host "  .\start_all.ps1 -AhkExe `"D:\Admin\autokey\AutoHotkeyU64.exe`""
